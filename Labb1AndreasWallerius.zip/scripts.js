var request = new XMLHttpRequest()

request.open('GET', '')

request.onload = function (){

    
}